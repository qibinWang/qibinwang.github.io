// 第二题：
function check(num){
    return (num > 0) && ((num & (num - 1)) == 0);
}

function readInput(input) {
  	console.log(check(input));
}

process.stdin.on('data', processLine => {
    processLine.toString('utf-8').split('\n')
        .map(x => x.trim())
        .filter(x => !!x)
        .map(data => {
            readInput(data)
        })
})
