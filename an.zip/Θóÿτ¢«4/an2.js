function getLength(serial) {
    const uri = serial.split(',').map((value) => {
        return `%${value}`
    }).join('')

    try {
        const string = decodeURI(uri)
        return string.length
    } catch(e) {
        return 0
    }
}

process.stdin.on('data', processLine => {
    processLine.toString('utf-8').split('\n')
        .map(x => x.trim())
        .filter(x => !!x)
        .map(data => {
            readInput(data)
        })
})


function readInput(input) {
   console.log(getLength(input) )
}

