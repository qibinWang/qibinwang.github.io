function getP( c) {
	let count =  Math.ceil(1 / c);
	let temp = 1;
	let last = 0;
	let sum = 0;
	for (let i = 1; i <= count; i++) {
		temp -= last;
		last = temp * Math.min(1, (c * i));
		sum += last * i;
	}
	let result = (1/sum*100).toFixed(0)
	return `${result}%`;
}


function readInput(input) {
     var temInput = input.replace("%", "")
     let value = (parseFloat(temInput).toFixed(0)/100)
     console.log(getP(value))
}

process.stdin.on('data', processLine => {
    processLine.toString('utf-8').split('\n')
        .map(x => x.trim())
        .filter(x => !!x)
        .map(data => {
            readInput(data)
        })
})