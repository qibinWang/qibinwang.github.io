var canJump = function (nums) {
    let reach = 1;
    const size = nums.length;
    for (let i = 2; i <= size; i++) {
        if (nums[size - i] < reach)
            // 如果这个节点不能达到
            reach++;
        else {
            //这个节点可以达到
            reach = 1;
        }
    }
    return reach == 1;

};

function readInput(input) {
    var temInput = input.replace("[", "")
    temInput = temInput.replace("]", "")
    let final = temInput.split(",")
    console.log(canJump(final))
}

process.stdin.on('data', processLine => {
    processLine.toString('utf-8').split('\n')
        .map(x => x.trim())
        .filter(x => !!x)
        .map(data => {
            readInput(data)
        })
})


//调用示例 node an2.js < in.txt