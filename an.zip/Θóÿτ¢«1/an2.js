// 第二问:
function zigzagToInt(n) {
    return (n >>> 1) ^ -(n & 1);
}

let inputValue = ["0x268cb43","0x7ff","0x2b7b","0x123a","0xf6","0x282"]
for (var i=0; i<inputValue.length; i++)
{ 
    let value  = parseInt(inputValue[i],16)
    let result = zigzagToInt(value)
    console.log(result);
}

