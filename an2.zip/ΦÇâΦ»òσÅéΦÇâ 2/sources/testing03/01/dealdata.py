# -*- coding: utf-8 -*-
# @Time    : 2023/5/24 10:42
# @Author  : Yehao Wan(九渊)
# @Site    : 
# @File    : dealdata.py
import pandas as pd
import shutil
import os


def dodealtrainingdata():
    """
    音频数据集处理；
    音频文件存放目录org_mp3filepath：voice
    音频文件文件内容文本及相关信息保存文件：voicetext.xlsx
    通过编码实现音频文件的训练集与验证集的样本按8:2的比例划分并分别保存为training/mp3，validation/mp3目录中；
          实现划分后样本的音频文件加载路径及性别标签信息的重构，且内容分别保存至training/label.txt，validation/label.txt文件中
    :return:
    """
    org_mp3filepath = "voice"
    voicetextpath = "voicetext.xlsx"
    """从该处要求补全代码："""
    """参考答案：考生不可见"""
    # 读取xlsx获取样本路径信息
    pdfile = pd.read_excel(voicetextpath)
    mp3filenames, genders = pdfile["path"].tolist(), pdfile["gender"].tolist()
    femalesamples = []
    malesamples = []
    for mpsfilename, gender in zip(mp3filenames, genders):
        # 按提议转换性别标签内容
        if gender == "female":
            femalesamples.append([mpsfilename, 1])
        else:
            malesamples.append([mpsfilename, 0])

    traininglabel = "training/label.txt"
    validlabel = "validation/label.txt"
    # 训练集样本集标签构建
    with open(traininglabel, mode="a", encoding="utf-8") as f:
        for index in range(int(len(femalesamples) * 0.8)):
            shutil.copy(os.path.join(org_mp3filepath, femalesamples[index][0]),
                        os.path.join("training/mp3", femalesamples[index][0]))
            f.write(os.path.join("training/mp3", femalesamples[index][0]) + " " + str(femalesamples[index][1]))
            f.write("\n")
        for index in range(int(len(malesamples) * 0.8)):
            shutil.copy(os.path.join(org_mp3filepath, malesamples[index][0]),
                        os.path.join("training/mp3", malesamples[index][0]))
            f.write(os.path.join("training/mp3", malesamples[index][0]) + " " + str(malesamples[index][1]))
            f.write("\n")

    # 验证集样本集标签构建
    with open(validlabel, mode="a", encoding="utf-8") as vf:
        for index in range(len(femalesamples) - int(len(femalesamples) * 0.2), len(femalesamples)):
            shutil.copy(os.path.join(org_mp3filepath, femalesamples[index][0]),
                        os.path.join("validation/mp3", femalesamples[index][0]))
            vf.write(os.path.join("validation/mp3", femalesamples[index][0]) + " " + str(femalesamples[index][1]))
            vf.write("\n")
        for index in range(len(malesamples) - int(len(malesamples) * 0.2), len(malesamples)):
            shutil.copy(os.path.join(org_mp3filepath, malesamples[index][0]),
                        os.path.join("validation/mp3", malesamples[index][0]))
            vf.write(os.path.join("validation/mp3", malesamples[index][0]) + " " + str(malesamples[index][1]))
            vf.write("\n")
    """作答结束"""

if __name__=="__main__":
    dodealtrainingdata()