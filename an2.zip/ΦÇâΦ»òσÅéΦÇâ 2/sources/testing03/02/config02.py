# -*- coding: utf-8 -*-
# @Time    : 2023/5/24 19:59
# @Author  : Yehao Wan(九渊)
# @Site    : 
# @File    : config.py

# 常量
PAD_token = 0  # 补足句长的pad占位符的index
SOS_token = 1  # 代表一句话开头的占位符的index
EOS_token = 2  # 代表一句话结尾的占位符的index
UNK_token = 3  # 代表不在词典中的字符
# 超参
BATCH_SIZE = 64                               # 一个batch中的对话数量（样本数量）
MAX_LENGTH = 40                             # 一个对话中每句话的最大句长
MIN_COUNT = 3                                 # trim方法的修剪阈值
TEACHER_FORCING_RATIO = 1.0      # 实行teacher_force_ratio的概率
LEARNING_RATE = 0.0001               # 学习率
CLIP = 50.0                                           # 梯度裁剪阈值
# 网络参数
hidden_size = 512                              # RNN隐层维度
encoder_n_layers = 2                         # encoder的cell层数
decoder_n_layers = 2                         # decoder的cell层数
dropout = 0.1                                      # 丢弃参数的概率

# 轮数与打印间隔
epoch_num = 20                  # 迭代轮数
print_interval = 3              # 打印间隔
save_interval = 20           # 保存模型间隔