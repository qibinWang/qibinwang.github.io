# -*- coding: utf-8 -*-
# @Time    : 2023/5/23 18:45
# @Author  : Yehao Wan(九渊)
# @Site    : 
# @File    : dialogtraining.py
# train.py
import torch
import random
from time import time
import os
import math
import config02 as cf
# 导入之前写好的函数或类
from process import vocab, trimAndReplace, DataLoader
from neural_network import EncoderRNN, LuongAttentionDecoderRNN, RNN_NET

# 定义运算设备
USE_CUDA = torch.cuda.is_available()
device = torch.device("cuda" if USE_CUDA else "cpu")

# 使用mask loss的方法避免计算pad的loss
# 计算非pad对应位置的交叉熵（负对数似然）
def maskNLLLoss(output, target, mask):
    """
    :param output: decoder的所有output的拼接    [batch_size, max_length, output_size]
    :param target: 标签，也就是batch的output_dialog对应的id序列  [batch_size, max_length]
    :param mask: mask矩阵    与target同形
    :return: 交叉熵损失、单词个数
    """

    target = target.type(torch.int64).to(device)
    mask = mask.type(torch.BoolTensor).to(device)

    total_word = mask.sum()  # 单词个数
    crossEntropy = -torch.log(torch.gather(output, dim=2, index=target.unsqueeze(2)))
    # crossEntropy : [batch_size, max_length, 1]
    loss = crossEntropy.squeeze(2).masked_select(mask).mean()
    loss = loss.to(device)
    return loss, total_word.item()


# 定义训练一个batch的逻辑
# 在这个batch中更新网络时，有一定的概率会使用teacher forcing的方法来加速收敛， 这个概率为teacher_forcing_ratio
def trainOneBatch(input_seq, input_length, target, mask, max_target_len,
                  encoder, decoder, encoder_optimizer, decoder_optimizer,
                  batch_size, clip, teacher_forcing_ratio,
                  encoder_lr_scheduler=None, decoder_lr_scheduler=None):
    """
    :param input_seq:  输入encoder的index序列 [batch_size, max_length]
    :param input_length:  input_seq中每个序列的长度 [batch_size]
    :param target:  每个input_dialog对应的output_dialog的index序列[batch_size, max_length]
    :param mask:  target对应的mask矩阵 [batch_size, max_length]
    :param max_target_len:  target中的最大句长
    :param encoder: encoder实例
    :param decoder: decoder实例
    :param encoder_optimizer: 承载encoder参数的优化器
    :param decoder_optimizer: 承载decoder参数的优化器
    :param batch_size: batch大小
    :param clip: 修剪梯度的阈值，超过该值的导数值会被裁剪
    :param teacher_forcing_ratio: 训练该batch启动teacher force的策略
    :param encoder_lr_scheduler: encoder_optimizer学习率调整策略
    :param decoder_lr_scheduler: decoder_optimizer学习率调整策略
    :return: 平均似然损失
    """
    # 清空优化器
    encoder_optimizer.zero_grad()
    decoder_optimizer.zero_grad()

    # 设置变量的运算设备
    input_seq = input_seq.to(device)
    input_length = input_length.to(device)
    target = target.to(device)
    mask = mask.to(device)

    decoder_output = torch.FloatTensor()  # 用来保存decoder的所有输出
    decoder_output = decoder_output.to(device)

    # encoder的前向计算
    encoder_output, encoder_hidden = encoder(input_seq, input_length)

    # 为decoder的计算初始化一个开头SOS
    decoder_input = torch.tensor([cf.SOS_token for _ in range(batch_size)]).reshape([-1, 1])
    decoder_input = decoder_input.to(device)

    # 根据decoder的cell层数截取encoder的h_n的层数
    decoder_hidden = encoder_hidden[:decoder.n_layers]

    # 根据概率决定是否使用teacher force
    use_teacher_forcing = True if random.random() < teacher_forcing_ratio else False

    if use_teacher_forcing:
        for i in range(max_target_len):
            # 执行一步decoder前馈，只计算了一个单词
            output, current_hidden = decoder(decoder_input, decoder_hidden, encoder_output)
            # output : [batch_size, output_size]
            # current_hidden : [1, batch_size, hidden_size]
            # 将本次time_step得到的结果放入decoder_output中
            decoder_output = torch.cat([decoder_output, output.unsqueeze(1)], dim=1)
            # 使用teacher forcing：使用target（真实的单词）作为decoder的下一次的输入，而不是我们计算出的预测值（计算出的概率最大的单词）
            decoder_input = target[:, i].reshape([-1, 1])
            decoder_hidden = current_hidden
    else:
        for i in range(max_target_len):
            # 执行一步decoder前馈，只计算了一个单词
            output, current_hidden = decoder(decoder_input, decoder_hidden, encoder_output)
            # output : [batch_size, output_size]
            # current_hidden : [1, batch_size, hidden_size]
            # 从softmax的结果中得到预测的index
            predict_index = torch.argmax(output, dim=1)
            # 将本次time_step得到的结果放入decoder_output中
            decoder_output = torch.cat([decoder_output, output.unsqueeze(1)], dim=1)
            decoder_input = predict_index.reshape([-1, 1])
            decoder_hidden = current_hidden

    # 计算本次batch中的mask_loss和总共的单词数
    mask_loss, word_num = maskNLLLoss(output=decoder_output, target=target, mask=mask)

    # 开始反向传播，更新参数
    mask_loss.backward()

    # 裁剪梯度
    torch.nn.utils.clip_grad_norm_(encoder.parameters(), clip)
    torch.nn.utils.clip_grad_norm_(decoder.parameters(), clip)

    # 更新网络参数
    encoder_optimizer.step()
    decoder_optimizer.step()
    # 调整优化器的学习率
    if encoder_lr_scheduler and decoder_lr_scheduler:
        encoder_lr_scheduler.step()
        decoder_lr_scheduler.step()

    return mask_loss.item()

def dotraining():
    """
    执行智能客服答应解决方案训练；
         其中：1）训练过程中网络参数配置参考config02.py中的设置
         通过完善代码，实现对话模型的具体构建。
    :return:
    """
    # 开始训练
    print("build vocab_list...")
    # 首先构建字典
    voc = vocab(name="corpus", pad_token=cf.PAD_token, sos_token=cf.SOS_token, eos_token=cf.EOS_token,
                unk_token=cf.UNK_token)
    # 载入数据
    pairs = voc.load_data(path="data/consultmsg.txt")
    print(f"load {len(pairs)} dialogs successfully")
    # 对数据进行裁剪
    pairs = trimAndReplace(voc=voc, pairs=pairs, min_count=cf.MIN_COUNT)
    print(f"there are {voc.num_words} words in the vocab")
    # 定义词向量嵌入矩阵
    embedding = torch.nn.Embedding(num_embeddings=voc.num_words,
                                   embedding_dim=cf.hidden_size,
                                   padding_idx=cf.PAD_token)
    # 创建encoder和decoder网络结构对象
    encoder = EncoderRNN(hidden_size=cf.hidden_size,
                         embedding=embedding,
                         n_layers=cf.encoder_n_layers,
                         dropout=cf.dropout)

    decoder = LuongAttentionDecoderRNN(score_name="dot",
                                       embedding=embedding,
                                       hidden_size=cf.hidden_size,
                                       output_size=voc.num_words,
                                       n_layers=cf.decoder_n_layers,
                                       dropout=cf.dropout)
    # 获取训练模型对象
    trainnet = RNN_NET(encoder, decoder)
    """从该处要求补全代码："""

    """参考答案：考生不可见"""
    if os.path.exists("model/bestmodel.pkl"):
        trainnet.load_state_dict(
            torch.load("model/bestmodel.pkl", map_location=device))
    trainnet = trainnet.to(device)
    # 配置优化器
    trainnet_optimizer = torch.optim.Adam(trainnet.parameters(), lr=cf.LEARNING_RATE)
    # 全局训练次数记录
    global_step = 0
    start_time = time()
    trainnet.train()
    print("start to train...")
    # 全局每轮每次损失的总和记录
    all_losstemp = []
    # 轮数遍历
    for epoch in range(cf.epoch_num):
        # 一轮训练各批次损失临时记录
        mask_loss_all = []
        train_loader = DataLoader(pairs=pairs, voc=voc, batch_size=cf.BATCH_SIZE, shuffle=True)
        # 遍历生成器
        for batch_num, alldatas in enumerate(train_loader):
            global_step += 1
            # alldatas : ["input_tensor", "input_length_tensor", "output_tensor", "mask", "max_length"]
            input_seq = alldatas[0].cuda()
            # input_length = alldatas[1].cuda()
            target = alldatas[2].cuda()
            output = trainnet(input_seq=input_seq, input_length=alldatas[1], target=target, max_target_len=alldatas[4])
            # 计算本次alldatas中的mask_loss和总共的单词数
            mask_loss, word_num = maskNLLLoss(output=output, target=alldatas[2], mask=alldatas[3])
            # 开始反向传播，更新参数
            mask_loss.backward()
            # 更新网络参数
            trainnet_optimizer.step()
            # 调整优化器的学习率
            loss = mask_loss.item()
            if global_step % cf.print_interval == 0:
                print("Epoch : {}\tbatch_num : {}\tloss: {:.6f}\ttime point : {:.2f}s\tmodel_lr : {:.10f}".format(
                    epoch, batch_num, loss, time() - start_time, trainnet_optimizer.param_groups[0]["lr"]
                ))
            # 将check_point存入./data/check_points这个文件夹中
            mask_loss_all.append(loss)
        if len(all_losstemp) < 1 or sum(mask_loss_all) < min(all_losstemp):
            check_point_save_path = f"model/newbestmodel.pkl"
            torch.save(trainnet.state_dict(), check_point_save_path)
            print(f"save best model to {check_point_save_path}")
        all_losstemp.append(sum(mask_loss_all))
    """作答结束"""
if __name__=="__main__":
    dotraining()