# -*- coding: utf-8 -*-
# @Time    : 2023/7/12 13:42
# @Author  : Yehao Wan(九渊)
# @Site    : 
# @File    : testtraining.py
import torch
import torch.nn as nn
from torch.utils.data import Dataset, DataLoader
import numpy

device = "cpu"

"""
本测试用例任务描述：基于深度网络实现简单的二分类任务
训练数据描述：
     特征数据：通过随机生成的方式获得100份每份特征为10的样本，样本组织形态为100x20的二维数组
     标签：通过随机生成的方式，获得100份值为0或者1的标签数据，表示类别为0或者1
     然后通过数据的处理，实现深度网络对二分类任务的学习
"""
class ClassificVal(nn.Module):
    def __init__(self, inputsize, outputsize):
        super(ClassificVal, self).__init__()
        self.layer1 = nn.Linear(in_features=inputsize, out_features=256)
        self.layer2 = nn.Linear(in_features=256, out_features=128)
        self.layer3 = nn.Linear(in_features=128, out_features=outputsize-1)
        self.dealoutput = nn.Softmax(dim=1)
        pass

    def forward(self, x):
        res = self.layer1(x)
        res = self.layer2(res)
        res = self.layer3(res)
        res = self.dealoutput(res)
        return res


class DatasetDeal(Dataset):
    def __init__(self, datalist: list):
        super(DatasetDeal, self).__init__()
        self.datalist = datalist
        pass

    def __len__(self):
        return len(self.datalist)

    def __getitem__(self, index):
        input = self.datalist[index][0:len(self.datalist[index]) - 1]
        label = self.datalist[index][-1]
        return torch.tensor(input.astype(numpy.float32)), torch.tensor([label.astype(numpy.float32)])


def training():
    # 输入维度
    inputdim = 20
    # 每批次处理的样本
    batchsize = 10
    # 类别数
    classnum = 2
    # 学习率
    learnrate = 0.001
    # 轮数
    epoch = 10
    # 构建学习数据（100，20）
    alldata = numpy.random.random((100, inputdim))
    # 构建学习标签（100，1）
    label = numpy.random.randint(low=0, high=2, size=(100, 1))
    # 将学习数据与标签数据拼接
    training = numpy.concatenate((alldata, label), axis=1)
    # 学习数据处理
    datadealset = DatasetDeal(training)
    # 学习数据加载（加载的是处理后的数据）
    trainingdataloader = DataLoader(datadealset, batch_size=batchsize, shuffle=True)
    # 创建模型训练对象
    model = ClassificVal(inputsize=inputdim, outputsize=classnum)
    #*************************************************************
    model.to(device)
    model.train()
    opotimer = torch.optim.



    # for i in epoch:


    # 训练完毕保存模型
    torch.save(model.state_dict(), "test_model.pkl")


if __name__ == "__main__":
    training()
