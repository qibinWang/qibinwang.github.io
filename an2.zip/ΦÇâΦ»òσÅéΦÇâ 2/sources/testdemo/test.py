import os
# line = " 这是 一个 字符串" #字符串对象定义
# print(line.strip())
# print(line.split(" "))

list_vals = ["这是什么",["嘿嘿","哈哈"],"我在外面了","这个是什么呀",12306,0.1]
# list_vals.remove(list_vals[0])
# join_str = "xxx".join(list_vals)
# join_str = "".join("xxx")
# print(len(list_vals))

#按元素本身读取元素
# for val in list_vals:
#       print(type(val))

# for indx in range(len(list_vals)):
#       print(type(list_vals[indx]))


dict_vals = {"张三":[99,96],"李四":[100,90]} #字符串对象定义
# print(dict_vals.keys())
# print(dict_vals.items())
# dict_vals["张三"] .append(100)
# print(dict_vals)



curentPath = os.path.realpath(__file__)
parentPath = os.path.dirname(curentPath)
print(parentPath)