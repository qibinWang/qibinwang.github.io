# -*- coding: utf-8 -*-
# @Time    : 2023/7/12 13:42
# @Author  : Yehao Wan(九渊)
# @Site    : 
# @File    : testtraining.py
import torch
import torch.nn as nn
from torch.utils.data import Dataset, DataLoader
import numpy

device = "cpu"

"""
本测试用例任务描述：基于深度网络实现简单的二分类任务
训练数据描述：
     特征数据：通过随机生成的方式获得100份每份特征为10的样本，样本组织形态为100x20的二维数组
     标签：通过随机生成的方式，获得100份值为0或者1的标签数据，表示类别为0或者1
     然后通过数据的处理，实现深度网络对二分类任务的学习
"""
class ClassificVal(nn.Module):
    def __init__(self, inputsize, outputsize):
        super(ClassificVal, self).__init__()
        self.layer1 = nn.Linear(in_features=inputsize, out_features=256)
        self.layer2 = nn.Linear(in_features=256, out_features=128)
        self.layer3 = nn.Linear(in_features=128, out_features=outputsize-1)
        self.dealoutput = nn.Softmax(dim=1)
        pass

    def forward(self, x):
        res = self.layer1(x)
        res = self.layer2(res)
        res = self.layer3(res)
        res = self.dealoutput(res)
        return res


class DatasetDeal(Dataset):
    def __init__(self, datalist: list):
        super(DatasetDeal, self).__init__()
        self.datalist = datalist
        pass

    def __len__(self):
        return len(self.datalist)

    def __getitem__(self, index):
        input = self.datalist[index][0:len(self.datalist[index]) - 1]
        label = self.datalist[index][-1]
        return torch.tensor(input.astype(numpy.float32)), torch.tensor([label.astype(numpy.float32)])


def training():
    # 输入维度
    inputdim = 20
    # 每批次处理的样本
    batchsize = 10
    # 类别数
    classnum = 2
    # 学习率
    learnrate = 0.001
    # 轮数
    epoch = 10
    # 构建学习数据（100，20）
    alldata = numpy.random.random((100, inputdim))
    # 构建学习标签（100，1）
    label = numpy.random.randint(low=0, high=2, size=(100, 1))
    # 将学习数据与标签数据拼接
    training = numpy.concatenate((alldata, label), axis=1)
    # 学习数据处理
    datadealset = DatasetDeal(training)
    # 学习数据加载（加载的是处理后的数据）
    trainingdataloader = DataLoader(datadealset, batch_size=batchsize, shuffle=True)
    # 创建模型训练对象
    model = ClassificVal(inputsize=inputdim, outputsize=classnum)
    #*************************************************************
    model.to(device)
    # 打开网络的学习状态
    model.train()
    # 创建一个优化器
    opotimer = torch.optim.Adam(model.parameters(), lr=learnrate, betas=(0.99, 0.9999))
    # 创建一个损失计算策略方案
    loss = torch.nn.L1Loss()
    # 控制训练轮数
    for i in range(epoch):
        count = 0# 每轮训练的次数count，便于打印观察
        # 迭代训练
        for input, label in trainingdataloader:
            # 优化器缓存清楚
            opotimer.zero_grad()
            # 将输入数据指定计算设备环境
            input = input.to(device)
            # 将标签数据指定计算设备环境
            label = label.to(device)
            # 模型计算
            out = model(input)
            # 计算模型的损失
            lossval = loss(out, label)
            # 根据模型的损失反向计算各参数的梯度
            lossval.backward()
            # 修改模型参数
            opotimer.step()
            print(f"第{i + 1}轮，第{count + 1}批次，训练损失为：{round(lossval.item(), 6)}")
            # 一次计算结束，次数+1
            count+=1
    # 训练完毕保存模型
    torch.save(model.state_dict(), "test_model.pkl")


if __name__ == "__main__":
    training()
