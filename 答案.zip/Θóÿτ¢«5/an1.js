// 第一题：
	let valueStr =  parseInt(511).toString(2)
	console.log(valueStr);

