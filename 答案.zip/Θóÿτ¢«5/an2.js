

// 第二题：
	function check(num){
	    return (num > 0) && ((num & (num - 1)) == 0);
	}
	console.log(check(128));

