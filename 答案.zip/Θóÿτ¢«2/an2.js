
var canJump = function(nums) {
    let reach = 1;
    const size = nums.length;
    for (let i = 2; i <= size; i++) {
            if(nums[size-i]<reach)
                // 如果这个节点不能达到
                reach++;
            else {
                //这个节点可以达到
                reach = 1;
            }
        }
        return reach==1;

};
console.log(canJump([3,2,1,0,4]))
