function getP( c) {
	let count =  Math.ceil(1 / c);
	let temp = 1;
	let last = 0;
	let sum = 0;
	for (let i = 1; i <= count; i++) {
		temp -= last;
		last = temp * Math.min(1, (c * i));
		sum += last * i;
	}

	let result = (1/sum*100).toFixed(0)
	return `${result}%`;
}

console.log(getP(0.085));

