


function getP( c) {
	let count =  Math.ceil(1 / c);
	let temp = 1;
	let last = 0;
	let sum = 0;
	for (let i = 1; i <= count; i++) {
		temp -= last;
		last = temp * Math.min(1, (c * i));
		sum += last * i;
	}
	return 1/sum;
}

let min = 0;
let max = 100;
let trim = "60"
let per = parseInt(trim)

while (true) {
	let middle = ((min + max) / 2);
	let temp = getP(middle / 100);
	let tempPer = temp * 100
	tempPer = parseInt(tempPer)
	if (tempPer == per) {
		 console.log(`${parseInt(middle)}%`)
		return;
	} else if (tempPer > per) {
		max = middle;
	} else {
		min = middle;
	}
}

