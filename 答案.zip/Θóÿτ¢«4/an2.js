
function checkEntry(str) {
    let splitArr = str.split(",")
    var changeCodeArr = []
    splitArr.forEach(element => {
        changeCodeArr.push(parseInt(element, 16))
    });
    console.log(validUtf8(changeCodeArr))
}

function validUtf8(data) {
    var n = 0;
    var sum = 0;
    for(let i=0;i< data.length; i++){
        let value = data[i]
        if(n > 0){
            if(value >>6 !=2 ) return false;
            n--;
            if (n ==0 ) {
                sum ++
            }
        }else if(value >>7 == 0){
            n=0;
            sum ++
        }else if(value >>5 == 0b110){
            n=1;
        }else if(value >>4 == 0b1110){
            n=2;
        }else if(value >>3 == 0b11110){
            n=3;
        }else{
            return false;
        }
    }
    return sum;
}

checkEntry("E4,B8,A5,61,61,61,61,61")